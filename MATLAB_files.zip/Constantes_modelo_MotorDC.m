%% Parametros Motor DC - Excel - Experimental Parameters

% Momento Inercia
J=0.0017574; % [kg*m^2]
% Constante Friccion Viscosa
B=0.0016443; % [N*m*s]
% Constante Fuerza Electromotriz
ka=0.23152; % [V/ras*s]
% Constante de par motor
km=ka; % [N*m/A]
% Resistencia de Armadura
Ra=5.7851; % [Ohms]
% Inductancia Electrica
L=1.7088e-06; % [H]
%Voltaje en salida a Motor L298N
Vm=10.32; % [V]

%% Funcion de transferencia
G = tf(km, [J*L (B*L + J*Ra) (B*Ra + ka*km)]);
rlocus(G)