%% Ajuste de parámetros de Motor DC

load('expermitalData2.mat')
t = out.experimentalData(1:225, 1); % Tiempo
y_ft = out.experimentalData(177:end,2); % Salida Funcion de Transferencia
y_real = out.experimentalData(177:end,3); % Salida Modelo Real
u = out.experimentalData(177:end,4); % Entrada de Voltaje al Modelo
%% Datos Iniciales
% % Momento Inercia
% J=0.0017574; % [kg*m^2]
% % Constante Friccion Viscosa
% B=0.0016443; % [N*m*s]
% % Constante Fuerza Electromotriz
% ka=0.23152; % [V/ras*s]
% % Constante de par motor
% km=ka; % [N*m/A]
% % Resistencia de Armadura
% Ra=5.7851; % [Ohms]
% % Inductancia Electrica
% L=1.7088e-06; % [H]
% %Voltaje en salida a Motor L298N
% Vm=10.32; % [V]

% % Momento Inercia
% J=0.0012145; % [kg*m^2]
% % Constante Friccion Viscosa
% B=0.0020529; % [N*m*s]
% % Constante Fuerza Electromotriz
% ka=0.21381; % [V/ras*s]
% % Constante de par motor
% km=ka; % [N*m/A]
% % Resistencia de Armadura
% Ra=5.9688; % [Ohms]
% % Inductancia Electrica
% L=1.006e-6; % [H]
% % Voltaje en salida a Motor L298N
% Vm=10.32; % [V]

%% Variables de desición
vd0 = [J, B, ka, km ,Ra, L];

% Muestra el objetivo inicial
disp(['Initial SSE Objective: ' num2str(f_objetivo(vd0, out.experimentalData))])

%% Parámetros de Optimización
A = [];
b = [];
Aeq = [];
beq = [];
nlcon = [];

% Restricciones
lb = vd0*0.8; lb(end) = 1e-6;
ub = vd0*1.2; ub(end) = 1;

% options = optimoptions(@fmincon, 'Algorithm', 'interior-point');
vd = fmincon(@(vd)f_objetivo(vd,out.experimentalData), vd0, A, b, Aeq, beq, lb, ub, nlcon);

% Show final objective
disp(['Final SSE Objective: ' num2str(f_objetivo(vd, out.experimentalData))])

% Parametros del Motor Optimizados
J_op = vd(1);
B_op = vd(2);
ka_op = vd(3);
km_op = vd(4);
R_op = vd(5);
L_op = vd(6);
disp(['J: ' num2str(J_op)])
disp(['B: ' num2str(B_op)])
disp(['ka=km: ' num2str(ka_op)])
disp(['R: ' num2str(R_op)])
disp(['L: ' num2str(L_op)])

% Calcula la dinamica del modelo con los nuevos parametros
X = motor_simulate(vd, out.experimentalData);

plot(t, y_real, t, X(:,2), '--', t, y_ft, 'LineWidth',2)
ylabel('Velocidad (rad/s)')
legend('Motor Real', 'Modelo optimizado', 'Modelo inicial')

% Voltaje leido en los terminales del motor
Vm = 10.32;
